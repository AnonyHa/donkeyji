# $Id: __init__.py,v 1.8 2008/08/15 14:54:49 jribbens Exp $

__version__ = "0.07"
